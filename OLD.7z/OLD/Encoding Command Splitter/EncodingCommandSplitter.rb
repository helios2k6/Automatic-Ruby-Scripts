module EncodingCommandSplitter
	Infinity = 1.0/0

	class ArgsStruct
		attr_accessor :split, :exclusion, :input
		
		def initialize(split, exclusion, input)
			@split = split
			@exclusion = exclusion
			@input = input
		end
		
		def getSplit
			return @split
		end
		
		def getExclusiveZones
			return @exclusion
		end
		
		def getInput
			return @input
		end

	end

	class KeyframeDatabase
		attr_accessor :arrayOfIFrames, :totalNumberOfFrames
		
		def initialize(arrayOfIFrames, totalNumberOfFrames)
			@arrayOfIFrames = arrayOfIFrames
			@totalNumberOfFrames = totalNumberOfFrames
		end
		
		def getTotalNumberOfFrames
			return @totalNumberOfFrames
		end
		
		def getKeyFrames
			return @arrayOfIFrames
		end
		
		def getNearestIFrame(frame)
			if frame > @totalNumberOfFrames then 
				raise "Requested frame greater than total amount of frames"
			elsif frame == 0 then
				return 0
			end
			
			closestDistance = Infinity
			closestIFrame = 0
			for i in @arrayOfIFrames
				localDist = (frame - i).abs
				if(localDist < closestDistance) then
					closestDistance = localDist
					closestIFrame = i
				end
			end
			return closestIFrame
		end
		
		def getNextIFrame(offset)	
			closestDistance = Infinity
			
			i = 0
			while i < @totalNumberOfFrames
				currentFrame = @arrayOfIFrames[i]
				if currentFrame > offset then
					return currentFrame
				end
				i = i + 1
			end
		end
	end

	def locateKeyframes(keyframeFileName)
		arrayOfFrames = Array.new
		index = 0
		count = 0;
		keyframeFile = IO.new(IO.sysopen(keyframeFileName, "r"))
		
		line = keyframeFile.gets
		while line != nil
			result = line.scan(/(type:I)/)
			if result.size > 0 then
				frameNumber = line.scan(/(in:)(\d+)/)
				arrayOfFrames.push(Integer(frameNumber[0][1]))
			end
			
			isFrame = line.scan(/(type:)/)
			if isFrame.size > 0 then
				count = count + 1
			end
			
			line = keyframeFile.gets
			index = index + 1
		end
		
		keyframeDB = KeyframeDatabase.new(arrayOfFrames, count)
		
		return keyframeDB
	end

	def printHelp
		#header
		puts("Video Encoding Splitter")
		puts("Usage: prog [keyframe file] [options]")
		puts("Options:")
		
		#--splits
		puts("\t--splits")
		puts("\t\tNumber of splits you want")
		
		#--exclude
		puts("\t--exclude:[start,end+1)")
		puts("\t\tSpecify an exclusion area where all frames will be encoded contiguously.")
		puts("\t\tCan specify multiple exclusion areas by using the --exclude switch multiple times")
		
		#examples
		puts("Example:")
		puts("\t--splits 10 --exclude:10,15 --exclude:20,31")
		puts("\t\tSplit video into 10 pieces, exclude frames 10-14 and frames 20-30")
	end


	def processArgs(args)
		if args.length < 2 then
			printHelp()
			exit
		end
		
		size = args.size
		
		exclusiveZones = Array.new
		splits = 0
		
		i = 0
		begin
			while i < args.size
				currentInput = args[i]
				scanSplits = currentInput.scan(/(--splits)/)
				scanExclude = currentInput.scan(/(--exclude:)(\d+),(\d+)/)
				
				#puts("Current input: #{currentInput}")
				#puts("Scan Splits #{scanSplits}")
				#puts("Scan Exclude #{scanExclude}")
				
				if scanSplits.size > 0 then
					i = i + 1
					numberOfSplits = args[i]
					splits = Integer(numberOfSplits)
				elsif scanExclude.size > 0 then
					startExclude = Integer(scanExclude[0][1])
					endExclude = Integer(scanExclude[0][2])
					
					exclusiveZones.push(startExclude)
					exclusiveZones.push(endExclude)
				end
				
				i = i + 1
			end
		
		inputFile = args[0]

		rescue ArgumentError
			puts("Incorrect arguments")
			exit 1
		end
		
		argStruct = ArgsStruct.new(splits, exclusiveZones, inputFile)
		
		return argStruct	
	end

	def isInExclusiveZone(exclusiveZones, frame)
		i = 0
		
		while i < exclusiveZones.size
			exclusiveStart = exclusiveZones[i]
			exclusiveEnd = exclusiveZones[i+1]
			if frame >= exclusiveStart && frame < exclusiveEnd then
				return true
			end
			i = i + 2
		end
		
		return false
	end

	def calcSplits(splits, exclusiveZones, keyFrameDatabase)
		#Sanity checks
		if(splits >= keyFrameDatabase.getTotalNumberOfFrames)
			puts("More splits than total number of frames")
			exit
		end
		
		takenFrames = Array.new
		
		#add start frame
		takenFrames.push(0)
		
		#add end frame
		takenFrames.push(keyFrameDatabase.getTotalNumberOfFrames-1)
		
		#add exclusive frames
		for i in exclusiveZones
			takenFrames.push(i)
		end
		
		chunkSize = keyFrameDatabase.getTotalNumberOfFrames / splits
		
		i = 1
		
		while i < splits
			predictedFrame = keyFrameDatabase.getNearestIFrame(i * chunkSize)
			
			if isInExclusiveZone(exclusiveZones, predictedFrame) then
				#We're in an exclusive zone. Get the nearest iframe
				while true
					predictedFrame = keyFrameDatabase.getNextIFrame(predictedFrame)
					if !isInExclusiveZone(exclusiveZones, predictedFrame) then
						break
					end
				end		
			end
			
			takenFrames.push(predictedFrame)
			
			i = i + 1
		end
		
		return takenFrames.sort!
	end
	
	def executeAsLibrary(args)
		#Process Args
		argStruct = processArgs(args)
		
		#Hydrate Database
		keyFrameDatabase = locateKeyframes(argStruct.getInput)
		
		#Calculate split areas
		splits = calcSplits(argStruct.getSplit, argStruct.getExclusiveZones, keyFrameDatabase)
		
		i = 0
		seekArray = []
		frameAmounts = []
		while i < splits.size - 1
			seekArray[i] = splits[i]
			frameAmounts[i] = splits[i+1] - splits[i]
			i = i + 1
		end
		
		return answer = [seekArray, frameAmounts]
	end
	
	def executeFromCommandLine(args)
		#Process Args
		argStruct = processArgs(args)
		#Hydrate Database
		keyFrameDatabase = locateKeyframes(argStruct.getInput)
		#Calculate split areas
		splits = calcSplits(argStruct.getSplit, argStruct.getExclusiveZones, keyFrameDatabase)
		
		i = 0
		puts("-----------------------")
		puts("---Calculated Splits---")
		while i < splits.size - 1
			puts("[#{splits[i]},\t#{splits[i+1]})\tDiff = #{splits[i+1] - splits[i]}")
			i = i + 1
		end	
	end
end