module AutoEncodingUtilities
	#List of Available Media Formats
	AVAILABLE_MEDIA_FORMATS = ["AVI", "MKV", "MP4", "WMV"]
	
	#Constant names
	MKV_EXTRACT = "mkvextract.exe"
	MKV_MERGE = "mkvmerge.exe"
	
	MP4BOX = "mp4box.exe"
	
	MEDIAINFO = "mediainfo.exe"
	
	#Path Variables
	TOOLS_FOLDER = "tools"
	
	MKV_TOOLS_FOLDER = TOOLS_FOLDER + File::SEPARATOR + "mkvtools"
	MP4_TOOLS_FOLDER = TOOLS_FOLDER + File::SEPARATOR + "mp4box"
	MEDIAINFO_FOLDER = TOOLS_FOLDER + File::SEPARATOR + "mediainfo"
	
	#mkv tools
	MKV_EXTRACT_PATH = MKV_TOOLS_FOLDER + File::SEPARATOR + MKV_EXTRACT
	MKV_MERGE_PATH = MKV_TOOLS_FOLDER + File::SEPARATOR + MKV_MERGE
	
	#MP4Box
	MP4BOX_PATH = MP4_TOOLS_FOLDER + File::SEPARATOR + MP4BOX
	
	#mediainfo
	MEDIAINFO_PATH = MEDIAINFO_FOLDER + File::SEPARATOR + MEDIAINFO
	
	def identifyMediaType(fileName)
		
	end
	
	def findFirstSubtitleTrack(fileName)
	
	end
	
	def extractTrack(fileName, trackNumber)
	
	end
	
	
end