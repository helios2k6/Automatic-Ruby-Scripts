def calculateHandProbability(outs, numberOfCards)
	return outs/numberOfCards
end

def calculatePotOdds(amountToBet, amountInPot)
	return amountInPot/amountToBet
end

def main()
	puts("Texas Hold'em Hand Odds and Pot Odds Calculator")
	
	puts("Calculate hand odds")
	puts("How many outs do you have? ")
	outs = gets.chomp.to_f
	
	puts("Are you right before the turn or the river?")
	puts("Hint: Flop --> Turn --> River")
	
	stage = gets.chomp
	
	numberOfCards = 52.0
	
	if stage.casecmp("turn") then
		numberOfCards = 47.0
	elsif stage.casecmp("river") then
		numberOfCards = 46.0
	else
		puts("I don't know what stage you're on")
		exit
	end
	
	handProb = calculateHandProbability(outs, numberOfCards)
		
	handOdds = (1.0 - handProb) / handProb
	
	puts("Calculate pot odds")
	puts("How much money is in the pot?")
	potAmount = gets.chomp.to_f
	
	puts("How much is the bet to you?")
	betAmount = gets.chomp.to_f
	
	potOdds = calculatePotOdds(betAmount, potAmount)
	
	puts("------Summery------")
	puts
	puts("[Hand]:\t1 to #{handOdds}")
	puts("[Pot]:\t1 to #{potOdds}")
	puts
	
	puts("------VERDICT------")
	if potOdds >= handOdds then
		puts("GO FOR IT!")
	else
		puts("FOLD")
	end
	
end

main