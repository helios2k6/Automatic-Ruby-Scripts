MKV_EXTRACT = "C:\\Video Tools\\MKV Tool Nix\\mkvextract"

def processFile(file)
	extention = File.extname(file)
	if(extention == ".mkv") then
		currentFile = File.new(file)
		
		command = "\"#{MKV_EXTRACT}\" --ui-language en tracks \"#{file}\" 3:\"#{File.basename(file, ".mkv")}.ass\""

		system(command)

		currentFile.close()
	end
	
end



def main()
	Dir.foreach("."){ |fileName| processFile(fileName)}
end

main()