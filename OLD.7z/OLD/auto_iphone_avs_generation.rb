FORMAT_ARRAY = ["avi", "mkv", "mp4", "wmv"]
MKV_EXTRACT = "C:\\Video Tools\\MKV Tool Nix\\mkvextract"

X264_ROOT_COMMAND = ""

def extractSubtitle(file)
	extention = File.extname(file)
	subtitleName = ""
	if(extention == ".mkv") then
		currentFile = File.new(file)
		subName = "#{File.basename(file, ".mkv")}.ass"
		subtitleName = subName
		
		command = "\"#{MKV_EXTRACT}\" --ui-language en tracks \"#{file}\" 3:\"#{subName}\""

		system(command)

		currentFile.close()
	end
	return subtitleName
end

def generate_avs(file, subtitleName)
	extention = File.extname(file)
	
	baseName = File.basename(file, extention)
	
	avsFileName = ""
	
	if FORMAT_ARRAY.include?(extention.delete(".")) then
		#We have a media file
		avisynthFile = File.new(baseName + ".avs", "w")
		avsFileName = baseName + ".avs"
		avisynthString = "x = \"#{file}\" \n" + 
			"ffindex(x)\n" + 
			"audiodub(ffvideosource(x), ffaudiosource(x))\n" +
			"textsub(\"#{subtitleName}\")"
		avisynthFile.puts(avisynthString)
		avisynthFile.close()
	end
	return avsFileName
end

def main()
	arrayOfFiles = []
	arrayOfCommands = []
	Dir.foreach("."){ |fileName| arrayOfFiles.push(fileName)}
	
	#Extract 3rd track
	i = 0
	
	while i < arrayOfFiles.size
		currentFile = arrayOfFiles[i]
		subName = extractSubtitle(currentFile)
		avsName = generate_avs(currentFile, subName)
		i++
	end
end

main()