require './AVS'
require './MediaInfoUtils'

X264_ENCODING_COMMAND = "x264 --crf 21 --deblock 2:2 --psy-rd 0.3 --level 3.1 --profile main --b-pyramid none --bframes 16 --sar 1:1 --ssim --psnr"
#X264_ENCODING_COMMAND = "x264 --crf 21 --deblock 2:2 --psy-rd 0.3 --level 4.2 --profile high --aud --sar 1:1 --vbv-maxrate 31250 --vbv-bufsize 31250 --b-pyramid none --bframes 16 --sar 1:1 --ssim --psnr"

def main
	arrayOfMediaFiles = []
	cd = Dir.new(".")
	cd.each{|file| processFile(file, arrayOfMediaFiles)}
	
	arrayOfSubtitleFiles = []
	
	avsFiles = []
	
	commandArray = []
	
	for mediaFile in arrayOfMediaFiles
		name = mediaFile.fullPathFile
		basename = File.basename(name, ".mkv")
	
		subtitleFile = MediaInfoUtils.demultiplexSubtitleTrack(mediaFile)
		avsFile = AVS.generateAVSFile(mediaFile.fullPathFile, subtitleFile, "spline64resize(1152, 648)")
		arrayOfSubtitleFiles.push(subtitleFile)
		avsFiles.push(avsFile)
		
		command = X264_ENCODING_COMMAND + " --output \"#{basename}.264\" \"#{avsFile}\""
		commandArray.push(command)
	end
	
	for c in commandArray
		puts("Executing command #{c}")
		system(c)
	end
end

def processFile(file, arr)
	basename = File.basename(file)
	extension = File.extname(file)
	if extension == ".mkv" then
		mediaFile = MediaInfoUtils.getMediaInfo(file)
		arr.push(mediaFile)
	end
end

main
