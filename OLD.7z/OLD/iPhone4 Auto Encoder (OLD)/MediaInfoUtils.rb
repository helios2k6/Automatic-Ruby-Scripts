require "rexml/document"
include REXML

module MediaInfoUtils
	#List of Available Media Formats
	@AVAILABLE_MEDIA_FORMATS = ["AVI", "MKV", "MATROSKA", "MP4", "MPEG-4", "WMV"]
	
	#MediaType - Extension Hash
	MEDIA_TYPE_TO_EXTENSION = Hash.new
	MEDIA_TYPE_TO_EXTENSION["MPEG-4"] = ".mp4"
	MEDIA_TYPE_TO_EXTENSION["Matroska"] = ".mkv"
	MEDIA_TYPE_TO_EXTENSION["AVI"] = ".avi"
	MEDIA_TYPE_TO_EXTENSION["Windows Media"] = ".wmv"
	
	#Constant names
	@MKV_EXTRACT = "mkvextract.exe"
	@MKV_MERGE = "mkvmerge.exe"
	
	@MP4BOX = "MP4Box.exe"
	
	@MEDIAINFO = "mediainfo.exe"
	
	class MediaFile
		attr_accessor :mediaInfoXML, :fullPathFile
		
		def initialize(mediaInfoXML, fullPathFile)
			@mediaInfoXML = mediaInfoXML
			@fullPathFile = fullPathFile
		end
		
		def getMediaType()
			generalElements = []
			@mediaInfoXML.each_element_with_attribute("type", "General"){|e| generalElements.push(e)}
			return generalElements[0].elements["Format"].get_text.value

		end
		
		def getFullPathFile()
			return @fullPathFile
		end
		
		def getListOfTrackTypes()
			trackTypeData = []
		
			@mediaInfoXML.elements.each("track"){|e| trackTypeData.push(e.attributes["type"])}
		
			return trackTypeData
		end
		
		def getBaseName()
			return File.basename(@fullPathFile, MEDIA_TYPE_TO_EXTENSION[getMediaType()])
		end
	end
	
	def self.getMediaInfo(file)
		args = "--output=XML \"#{file}\""
		
		#Don't ask why we have to execute this command like this. It's the stupidest thing ever
		xmlOutput = %x("#{@MEDIAINFO}" #{args})
		
		document = Document.new(xmlOutput)
		rootInfo = document.elements["Mediainfo/File"]
		
		return MediaFile.new(rootInfo, file)
	end
	
	def self.demultiplexSubtitleTrack(mediaFile)
		subtitleTrack = -1
		
		info = mediaFile.mediaInfoXML		
		#Find Subtitle Track
		textElements = []
		info.each_element_with_attribute("type", "Text"){|element| textElements.push(element)}
		
		#Get first subtitle track
		subtitleTrack = textElements[0].elements["ID"].get_text
		
		#Didn't find the sutbtitle track
		if subtitleTrack < 0 then
			return nil
		end
		
		subtitleFileName = mediaFile.getBaseName() + ".ass"
		command = "\"#{@MKV_EXTRACT}\" --ui-language en tracks \"#{mediaFile.getFullPathFile}\" #{subtitleTrack}:\"#{subtitleFileName}\""
		system(command)
		return subtitleFileName
	end
end
