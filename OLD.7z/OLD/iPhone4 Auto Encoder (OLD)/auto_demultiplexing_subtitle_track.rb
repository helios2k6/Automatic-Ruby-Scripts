require './MediaInfoUtils'

def main
	arrayOfMediaFiles = []
	cd = Dir.new(".")
	cd.each{|file| processFile(file, arrayOfMediaFiles)}
	
	for mediaFile in arrayOfMediaFiles	
		subtitleFile = MediaInfoUtils.demultiplexSubtitleTrack(mediaFile)
	end

end

def processFile(file, arr)
	basename = File.basename(file)
	extension = File.extname(file)
	if extension == ".mkv" then
		mediaFile = MediaInfoUtils.getMediaInfo(file)
		arr.push(mediaFile)
	end
end

main
