module AVS
	def self.generateAVSFile(mediaFile, subtitleFile, extraFilters=nil)
		avsFileName = File.basename(mediaFile, File.extname(mediaFile)) + ".avs"
		avsFile = File.open(avsFileName, 'w')
		script = "x = \"#{mediaFile}\"\nffindex(x)\nffvideosource(x, threads=1)\ngradfun2db()\ntextsub(\"#{subtitleFile}\")"
		avsFile.puts(script)
		if extraFilters != nil then
			avsFile.puts(extraFilters)
		end

		avsFile.close
		
		return avsFileName
	end
end