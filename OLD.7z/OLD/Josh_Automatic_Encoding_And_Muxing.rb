FOLDER_PREFIX = "C:\\Users\\Strikezcoal\\Desktop\\KWZ\\"

X264_SETTINGS_1080p = "FILL IN YOUR SETTINGS HERE" #Do not put the --output flag here
X264_SETTINGS_720p = "FILL IN YOUR SETTINGS HERE" #Do not put the --output flag here

MP4BoxLocation = "C:\\Program Files\\megui\\tools\\mp4box\\MP4Box.exe"

#264 files
NAME_OF_EP_3_1080p_264 = "KWZ_03_1080.264"
NAME_OF_EP_4_1080p_264 = "KWZ_04_1080.264"

NAME_OF_EP_3_720p_264 = "KWZ_03_720.264"
NAME_OF_EP_4_720p_264 = "KWZ_04_720.264"

#audio files
NAME_OF_AUDIO_3 = "STAGE_A_03.mp4"
NAME_OF_AUDIO_4 = "STAGE_A_04.mp4"

#avisynth files
NAME_OF_AVISYNTH_3_1080p = "STAGE_A_03-1080.avs"
NAME_OF_AVISYNTH_3_720p = "STAGE_A_03-720.avs"
NAME_OF_AVISYNTH_4_1080p = "STAGE_A_04-1080.avs"
NAME_OF_AVISYNTH_4_720p = "STAGE_A_04-720.avs"

# final files
NAME_OF_FINAL_FILE_3_1080 = "[N LogN EG] Kore Wa Zombie Desuka (3) [X264 PS3 1080p AAC BD].mp4"
NAME_OF_FINAL_FILE_3_720 = "[N LogN EG] Kore Wa Zombie Desuka (3) [X264 PS3 XBOX 720 AAC BD].mp4"

NAME_OF_FINAL_FILE_4_1080 = "[N LogN EG] Kore Wa Zombie Desuka (4) [X264 PS3 1080p AAC BD].mp4"
NAME_OF_FINAL_FILE_4_720 = "[N LogN EG] Kore Wa Zombie Desuka (4) [X264 PS3 XBOX 720 AAC BD].mp4"

def main()
	puts("Encoding 1080p Episode 3 now")
	system("x264 #{X264_SETTINGS_1080p} --output \"#{NAME_OF_EP_3_1080p_264}\" \"#{NAME_OF_AVISYNTH_3_1080p}\"")
	#puts("x264 #{X264_SETTINGS_1080p} --output #{NAME_OF_EP_3_1080p_264} \"#{NAME_OF_AVISYNTH_3_1080p}\"")
	
	puts("Muxing Episode 3 1080p")
	system("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_3_1080p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_3}\" -new \"#{NAME_OF_FINAL_FILE_3_1080}\"")
	#puts("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_3_1080p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_3}\" -new \"#{NAME_OF_FINAL_FILE_3_1080}\"")
	
	puts("Encoding 1080p Episode 4 now")
	system("x264 #{X264_SETTINGS_1080p} --output \"#{NAME_OF_EP_4_1080p_264}\" \"#{NAME_OF_AVISYNTH_4_1080p}\"")
	#puts("x264 #{X264_SETTINGS_1080p} --output #{NAME_OF_EP_4_1080p_264} \"#{NAME_OF_AVISYNTH_4_1080p}\"")

	puts("Muxing Episode 4 1080p")
	system("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_4_1080p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_4}\" -new \"#{NAME_OF_FINAL_FILE_4_1080}\"")
	#puts("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_4_1080p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_4}\" -new \"#{NAME_OF_FINAL_FILE_4_1080}\"")
	
	#---720p time---
	
	puts("Encoding 720p Episode 3 now")
	system("x264 #{X264_SETTINGS_1080p} --output \"#{NAME_OF_EP_3_720p_264}\" \"#{NAME_OF_AVISYNTH_3_720p}\"")
	#puts("x264 #{X264_SETTINGS_1080p} --output #{NAME_OF_EP_3_720p_264} \"#{NAME_OF_AVISYNTH_3_720p}\"")
	
	puts("Muxing Episode 3 720p")
	system("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_3_720p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_3}\" -new \"#{NAME_OF_FINAL_FILE_3_720}\"")
	#puts("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_3_720p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_3}\" -new \"#{NAME_OF_FINAL_FILE_3_720}\"")
	
	puts("Encoding 720p Episode 4 now")
	system("x264 #{X264_SETTINGS_1080p} --output \"#{NAME_OF_EP_4_720p_264}\" \"#{NAME_OF_AVISYNTH_4_720p}\"")
	#puts("x264 #{X264_SETTINGS_1080p} --output #{NAME_OF_EP_4_720p_264} \"#{NAME_OF_AVISYNTH_4_720p}\"")

	puts("Muxing Episode 4 720p")
	system("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_4_720p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_4}\" -new \"#{NAME_OF_FINAL_FILE_4_720}\"")
	#puts("\"#{MP4BoxLocation}\" -add \"#{FOLDER_PREFIX + NAME_OF_EP_4_720p_264}:fps=23.976\" -add \"#{FOLDER_PREFIX + NAME_OF_AUDIO_4}\" -new \"#{NAME_OF_FINAL_FILE_4_720}\"")
end

main()