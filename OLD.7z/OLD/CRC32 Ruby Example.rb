# Example of getting CRC32 from File name

# Step 1 - Get File Descriptor

x = IO.sysopen("FILE_NAME", "MODE") # Mode can equal 'r', 'r+', 'b', 'w'; usually equals 'rb'

#Step 2 - Make IO Object

l = IO.new(x, "MODE") # make sure you use the exact same mode as above

# Step 3 - Read the object into memory

h = l.read ; nil #this part at the end is to prevent Ruby from printing shit to Stdout

# Step 4 - Call the Zlib function. Be sure to "require" Zlib before doing this

require 'Zlib'
crc = Zlib.crc32(h, 0)

# Step 5 - You can print out the CRC32 checksum

crc.to_s # but this prints it out in base 10. We want base 16, so we use...

crc.to_s(16) # instead

#that's it

def getCRC32FromFile(fileName)
	#Don't forget require 'Zlib'
	file = IO.new(IO.sysopen(fileName, "rb"), "rb")
	binary = file.read ; nil
	crc = Zlib.crc32(binary, 0)
	return crc.to_s(16)
end

# Better example
def getCRC32FromFile(fileName)
	file = IO.new(IO.sysopen(fileName, "rb"), "rb")
	
	chunk = file.read(512000)
	
	temp_crc = nil
	
	while chunk != nil
		temp_crc = Zlib.crc32(chunk, temp_crc)
		chunk = file.read(512000)
	end
	
	file.close
		crc =  temp_crc.to_s(16).upcase!
	
	extraZeros = 8 - crc.length
	
	index = 0
	while(index < extraZeros)
		crc = "0" + crc
	end
	
	return crc
end