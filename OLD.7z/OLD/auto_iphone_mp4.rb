GUNDAM_00_ROOT = "Gundam 00"
EXTENSION = ".mp4"

X264_ROOT_COMMAND = "x264 --crf 21 --deblock 2:2 --psy-rd 0.3 --level 3.1 --profile main --b-pyramid none --sar 1:1 --ssim --psnr"

def generateAVSFile(mediaFile, extraFilters=nil)
	avsFileName = File.basename(mediaFile, File.extname(mediaFile)) + ".avs"
	avsFile = File.open(avsFileName, 'w')
	script = "x = \"#{mediaFile}\"\nffindex(x)\nffvideosource(x, threads=1)\ngradfun2db()\n"
	avsFile.puts(script)
	if extraFilters != nil then
		avsFile.puts(extraFilters)
	end

	avsFile.close
	
	return avsFileName
end

def processFile(file)
	thisFileExt = File.extname(file)
	baseName = File.basename(file, EXTENSION)
	if thisFileExt == EXTENSION then
		avsFile = generateAVSFile(file, "Spline64Resize(1152, 648)")
		command = X264_ROOT_COMMAND + " --output \"#{baseName}.264\" \"#{avsFile}\""
		puts("Executing #{command}")
		system(command)
	end
end

def main()
	dir = Dir.new(".")
	dir.each{|x| processFile(x)}
end

main()