module AutoEncoder
	#Use the "load" command to use another ruby file
	require 'Zlib'

	X264_SETTINGS = "SETTINGS"

	INPUT = "AVISYNTH SCRIPT"

	ROOT_NAME = "NAME OF ANIME"

	EPISODE_NUMBER = "Episode Number"

	AUDIO_FILE = "Audio File"

	def getCRC32FromFile(fileName)
		file = IO.new(IO.sysopen(fileName, "rb"), "rb")
		
		chunk = file.read(512000)
		
		temp_crc = nil
		
		while chunk != nil
			temp_crc = Zlib.crc32(chunk, temp_crc)
			chunk = file.read(512000)
		end
		
		file.close
		
		return temp_crc.to_s(16)
	end

	def verifySplits(seekPoints, frameAmounts)
		if seekPoints.size != frameAmounts.size then
			return false
		end
		
		for i in (1..(seekPoints.size()-1))
			forward = seekPoints[i]
			backward = seekPoints[i-1]
			
			amount = frameAmounts[i-1]
			
			if amount != (forward - backward) then
				return false
			end
			
		end
		
		return true
	end
	
	def execute()
	
	end
	
	def executeFromCommandLineOLD()
		seekPoints = []
		frameAmounts = []
		
		#Sanity Check
		if !verifySplits(seekPoints, frameAmounts) then
			puts("[ERROR]: Seek points do not match frame amounts")
			return
		end
		
		#Expect the Audio File
		if !File.exists?(AUDIO_FILE) then
			puts("[ERROR]: Audio file does not exist")
			return
		end
		
		fileNames = Array.new
		puts("Encoding parts")
		for index in (0..(seekPoints.size-1))
			currentName = "Stage A - part #{index}.264"
			fileNames.push(currentName)

			system("x264 " + X264_SETTINGS+ " --seek #{seekPoints[index]} --frames #{frameAmounts[index]}" + " --output \"#{currentName}\" \"#{INPUT}\"")
		end
		
		catCom = "cat "
		
		for name in fileNames
			catCom = catCom + " \"#{name}\" "
		end
		
		finalName = "Stage A - total.264"
		
		puts("Concatonating")
		catCom = catCom + " > \"#{finalName}\""
		
		system(catCom)
		
		puts("Muxing")	
		tempName = "muxed.mp4"
		
		muxingCommand = "MP4Box -add \"#{finalName}\" -add \"#{AUDIO_FILE}\" -new \"#{tempName}\""
		
		system(muxingCommand)
		
		puts("Renaming")
		crc32 = getCRC32FromFile(tempName)
		
		crc32.upcase!
		
		finalName = "[N LogN EG] #{ROOT_NAME} (#{EPISODE_NUMBER}) [X264 PS3 1080p AAC] [#{crc32}].mp4"
		
		File.rename(tempName, finalName)
		puts("finished encoding script")
	end
end